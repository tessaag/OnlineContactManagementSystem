package com.example.Online.Contact.Management.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineContactManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
